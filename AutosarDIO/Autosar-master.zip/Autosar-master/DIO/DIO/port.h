#include "STD_Types.h"

typedef uint8 Port_PinType ;

typedef enum {
	
	PORT_PIN_IN=0,
	PORT_PIN_OUT
	
	}Port_PinDirectionType;