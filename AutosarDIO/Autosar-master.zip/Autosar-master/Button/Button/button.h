#include "STD_Types.h"
#include "button_cfg.h"

STD_levelType Button_Read(uint8 Button_Num);
